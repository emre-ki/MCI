Introduction on how to use pyo on the BeagleBone Black with bela
================================================================ 

If you want to try pyo on the Bela platform, please follow the
instructions of the pyo-bela project:

[https://github.com/belangeo/pyo-bela](https://github.com/belangeo/pyo-bela)

(c) 2018 - belangeo
